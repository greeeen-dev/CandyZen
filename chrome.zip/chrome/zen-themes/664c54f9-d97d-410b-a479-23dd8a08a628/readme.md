# Better Tab Indicators

Options for customizing tabs on the sidebar.

- Adds a border around active tabs.
- Dims the title of tabs when unloaded.
