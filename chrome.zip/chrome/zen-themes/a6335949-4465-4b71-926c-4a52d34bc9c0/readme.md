# Better Find Bar

Improves the find bar by matching the browser theme, making it floating, more responsive, and moving it to the top of the page.
