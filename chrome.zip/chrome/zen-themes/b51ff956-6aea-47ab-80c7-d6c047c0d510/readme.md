Removes the bottom-left statusbar when hovering over a URL.
