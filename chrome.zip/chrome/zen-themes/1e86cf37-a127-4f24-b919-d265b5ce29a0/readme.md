Default Unified Extension Menu in Zen has lengthy description which added extra width on it. This theme will remove the Extension header and description, results on efficient panel size.

[Go here if you want to submit issue related to this theme](https://github.com/KiKaraage/ArcWTF/issues/new?assignees=KiKaraage&labels=Zen+Themes&projects=&template=zen-browser-theme-issue.md&title=%5BZBT%5D+)
