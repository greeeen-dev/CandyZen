# Exit Button Right Padding

Adds some padding next to the close button so it doesn't look like it's too close to the border.

Useful for certain Gnome themes that make the close button look like that.
