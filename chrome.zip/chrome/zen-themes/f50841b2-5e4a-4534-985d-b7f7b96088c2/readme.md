# zen-remove-split-view-tab-highlight

Mod for Zen Browser that removes the border highlight on the active tab in split view.

**Before:**

![With border highlight](https://raw.githubusercontent.com/JtdeGraaf/zen-remove-split-view-tab-highlight/20cc46e4acee3f95da0cab568331e953ec22a09f/withborderhighlight.png)

**After:**

![Without border highlight](https://raw.githubusercontent.com/JtdeGraaf/zen-remove-split-view-tab-highlight/20cc46e4acee3f95da0cab568331e953ec22a09f/withoutborderhighlight.png)
