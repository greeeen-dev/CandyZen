Hides the name of the extension on tabs loaded from the extension
