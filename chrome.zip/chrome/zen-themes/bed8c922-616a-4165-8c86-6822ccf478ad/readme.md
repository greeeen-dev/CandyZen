# Eric's Zen UI Tweak Box

Several optional UI changes for the Zen Browser. Completely changes the appearance of the browser with all tweaks enabled.

**Exit Button Right Padding theme users** - You don´t need that theme when using this one.

## Available Twe
