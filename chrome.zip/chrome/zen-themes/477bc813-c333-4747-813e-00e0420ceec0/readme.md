<p align="center">
  <img src="https://github.com/user-attachments/assets/0b66b793-f3d9-43c5-80f6-49488aefac2d" alt="Wazz's custom image"/>
</p>

# Move Essentials to Bottom

Moves your essentials to the bottom on the Sidebar.
