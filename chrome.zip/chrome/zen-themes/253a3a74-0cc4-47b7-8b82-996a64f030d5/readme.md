# Floating-History

A Zen browser mod for a detached and redesigned history sidebar, so that it appears to float on the left side and match the zen aesthetic.
