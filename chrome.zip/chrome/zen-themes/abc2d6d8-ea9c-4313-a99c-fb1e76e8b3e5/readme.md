Adds a drop shadow to the website's browser panel.
