# Zen Cleaned URL Bar

Cleans up zen's URL bar.
