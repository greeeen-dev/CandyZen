Enhanced audio indicator on tabs, visible when playing videos & audios.

Currently, mod is tailored to dark theme.
For now, mostly just styles it differently, later some customization and matching to color theme is planned.

Works as of `1.7.4b`
