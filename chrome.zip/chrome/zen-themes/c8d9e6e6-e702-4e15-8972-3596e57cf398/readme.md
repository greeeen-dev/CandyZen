Achieve the Zen state further! Hide Back and/or Forward button when you don't need them.

Both buttons will still shows when you arrange their positions from the Customize Toolbar menu.
