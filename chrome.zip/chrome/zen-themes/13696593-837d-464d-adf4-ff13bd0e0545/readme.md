# Download BG

Add a background to the active download indicator.
