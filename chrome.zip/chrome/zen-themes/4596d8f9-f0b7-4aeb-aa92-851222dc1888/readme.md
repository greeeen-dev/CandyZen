Show tab's close button only on hover, even on the active tab.
Zen browser always show the close button on the active tab by default, and this theme will disable that behavior and make close button on the active tab only visible on hover.
