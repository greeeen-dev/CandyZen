# Zen Minimal Exit Menu

A zen browser mod that changes the exit menu to 3 circles similar (but a bit different) to one in MacOS.
