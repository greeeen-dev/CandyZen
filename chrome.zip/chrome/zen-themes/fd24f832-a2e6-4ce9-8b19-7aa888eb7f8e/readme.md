# Quietify

this mod adds a calm visualizer type of animation to mute button to use with style and ease.

![image](https://raw.githubusercontent.com/wysh3/Zen-Mods/refs/heads/main/Quietify/image.png)
