
# cleaner-bookmark-menu
Remove unnecessary buttons from the toolbar bookmarks button.

![image](https://github.com/Pkcarreno/cleaner-bookmark-menu/blob/6b8878f1c5ffc7009a944faf8124d3c1cf7998e2/cleaner-bookmark-menu.png)
