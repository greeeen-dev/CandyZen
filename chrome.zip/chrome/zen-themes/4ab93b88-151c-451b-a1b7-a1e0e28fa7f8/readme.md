# No Scrollbar in Sidebar

Scrollbars are a useful feature to indicate the position of the content in a scrollable area. However, they can be distracting and take up space.

This theme removes the Sidebar Scrollbar while retaining the scroll functionality.
