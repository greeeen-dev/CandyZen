Changes the default left sided container color from tabs.
