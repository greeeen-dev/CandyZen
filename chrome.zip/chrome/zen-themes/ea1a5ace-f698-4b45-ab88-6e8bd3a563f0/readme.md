This theme contains a few small tweaks to the bookmarks toolbar:

- Center the toolbar
- Hide bookmark or bookmark folder icons
- Expand the toolbar on hover or search (only works with bookmarks toolbar enabled)

Each of these settings can be enabled individually by changing the configuration in the settings page.

To enable the bookmarks toolbar, press Ctrl + Shift + B

Feel free to suggest additional tweaks or improvements on the homepage.
