# Load Bar

Creates a sleek loading bar and mute status for single toolbar mode.
