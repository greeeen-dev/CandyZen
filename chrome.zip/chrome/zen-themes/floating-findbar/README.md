# zen-floating-findbar
Mod for Zen Browser that detaches findbar from edge of browser window so that it appears to float. 

## Options
- Increase space around edge of browser window and find bar; and
- Enable compact toolbar, similar to Smaller Compact Mode by n7itro.
