# Collapsed Tab Close Button

This theme adds a close button to the collapsed tabs in Zen Browser.

## What the extension does

This theme does:

- Display a close button on the collapsed tabs
- On hover, the close button will be shown

Have any suggestions or feedback? Feel free to open an issue in the [GitHub repository](https://github.com/burnt0rice/zen-themes/issues).
